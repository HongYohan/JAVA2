package sql;

import java.security.SecureRandom;

public class GeneratePW {
    public String generatePassword() {
        String needsForPW = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789" + "@#$%^&+=";
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        // 최소 요구 사항을 충족할 때까지 랜덤 비밀번호 생성
        while (password.length() < 8 || !password.toString().matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$")) {
            password.setLength(0); // StringBuilder 초기화

            for (int i = 0; i < 8; i++) { // 임의의 길이로 설정 (8자리)
                int randomIndex = random.nextInt(needsForPW.length());
                password.append(needsForPW.charAt(randomIndex));
            }
        }
        return password.toString();
    }
}
