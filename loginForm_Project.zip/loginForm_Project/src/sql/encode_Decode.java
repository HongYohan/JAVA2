package sql;

import java.util.Base64;

public class encode_Decode {
    String pw;
    public String encode(String input){
        this.pw= Base64.getEncoder().encodeToString(input.getBytes());
        return pw;
    }
    public String decode(String input){
        byte[] decodedBytes = Base64.getDecoder().decode(input);
        this.pw = new String(decodedBytes);
        return pw;
    }
}
