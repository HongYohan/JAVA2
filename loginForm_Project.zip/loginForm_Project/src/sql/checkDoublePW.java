package sql;

import javax.swing.*;
import java.util.Arrays;

public class checkDoublePW extends userDAO {
    JPasswordField jpw, jpw2, temp;
    char[] pw;
    // 비밀번호 이중 확인
    checkDoublePW(JPasswordField jpw, JPasswordField jpw2){
        this.jpw=jpw;
        this.jpw2=jpw2;
        temp=new JPasswordField();
    }
    
    //비번1 비번2 비교해서 1 -1 0으로 플래그 반환
    int check(){
        if(Arrays.equals(jpw2.getPassword(), temp.getPassword())){
            return -1;//2번 비번필드가 비었으면 -1 리턴
        }else if (Arrays.equals(jpw.getPassword(), jpw2.getPassword())){
            return 1;//1번과 2번필드가 같으면 즉 정상적인 입력일 경우
        }
        return 0;
    }
}
