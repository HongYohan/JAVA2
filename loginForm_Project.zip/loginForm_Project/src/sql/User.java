package sql;
//학생 정보 테이블 데이터 표현을 위한 클래스
public class User extends encode_Decode{

    // 컬럼정보에 따른 필드 선언
    private String id;
    private String password;
    private String name;
    private String phoneNumber="";
    private String address;
    private String email;

    // Getter/Setter 메서드
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPassword() {
        return decode(password);
    }
    public void setPassword(String pw) {
        this.password = encode(pw);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber +=phoneNumber;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
}