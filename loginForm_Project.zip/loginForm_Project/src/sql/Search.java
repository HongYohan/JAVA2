package sql;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

class SearchID extends JPanel implements ActionListener{
	// num 인증번호 배열
	int[] num = new int[4];
	
	// 값 가져오기
	String id, na, ph;
	
	// 필드 채우기
	JLabel jl1 = new JLabel("이름");
	JLabel jl2 = new JLabel("전화번호");
	JLabel jl3 = new JLabel("아이디: ");
	JLabel fid = new JLabel(); // find ID
	JLabel jl5 = new JLabel("인증번호");
	
	// 값 입력 필드
	JTextField jtf1 = new JTextField("",10);
	JTextField jtf2 = new JTextField("",10);
	JTextField jtf5 = new JTextField("",10);
	
	// 버튼
	JButton jb1 = new JButton("찾기");
	JButton jb2 = new JButton("확인");
	public SearchID() {
		// 2행 5열
		setLayout(new GridLayout(2,5));
		
		// 이름 입력칸 전화번호 입력칸 찾기(버튼)
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jb1);
		
		// 아이디: 빈칸 인증번호 입력칸 확인(버튼)
		add(jl3);
		add(fid);
		add(jl5);
		add(jtf5);
		add(jb2);
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae) {
		String s = ae.getActionCommand();
		String Name = jtf1.getText();
		String PhoneNumber = jtf2.getText();
		informPersonnal informP = new informPersonnal(Name,"");
		
		if(s.equals("찾기")) {
			if(Name.equals("") || PhoneNumber.equals("")) {
				JOptionPane.showMessageDialog(null,"사용자 정보 입력!","",JOptionPane.PLAIN_MESSAGE);
			} else {
				na = informP.name;
				ph = informP.phoneNumber;
				if(PhoneNumber.equals(ph)) {
					// 인증번호 생성 및 전역변수에 넣기
					Random r = new Random();
					for(int i=0; i<4;i++) {
						num[i] = r.nextInt(9)+1;
					}
					// 인증번호 출력
					String cert="";
					for(int i=0; i<4;i++) {
						cert+=Integer.toString(num[i]);
					}
					JOptionPane.showMessageDialog(null,"인증번호 : "+cert,"",JOptionPane.PLAIN_MESSAGE);
				}
				else {
					JOptionPane.showMessageDialog(null,"사용자 정보가 일치하지 않습니다.","",JOptionPane.PLAIN_MESSAGE);				}
			}
		}
		else {
			String c = jtf5.getText();
			if(c.length() != 4) JOptionPane.showMessageDialog(null,"인증번호를 입력하세요","",JOptionPane.PLAIN_MESSAGE);
			else {
				String[] x = c.split("");
				int[] wnum = new int[4];
				for(int i=0;i<4;i++) wnum[i] = Integer.parseInt(x[i]);
				int ca =0;
				for(int i=0;i<4;i++) {
					if(wnum[i] != num[i]) {
						ca=1;
						break;
					}
					else ca=0;
				}
				if(ca==1) {
					fid.setText("인증번호 다시!");
				}
				else {
					// 아이디 자료 가져오기
					id = informP.id;
					
					// found id에 아이디를 넣어두기
					fid.setText(id);
					jtf1.setText("");
					jtf2.setText("");
					jtf5.setText("");
				}
			}
		}
	}
}

class SearchPW extends JPanel implements ActionListener{
	// num 인증번호 배열
	int[] num = new int[4];
	
	// 값 가져오기
	String id, ph;
	
	// 명칭 라벨
	JLabel jl1 = new JLabel("아이디");
	JLabel jl2 = new JLabel("전화번호");
	JLabel jl3 = new JLabel("임시비밀번호: ");
	JLabel spw = new JLabel(); // set password 저장할 비밀번호 출력 칸!
	JLabel jl5 = new JLabel("인증번호");
	
	// 값 입력
	JTextField jtf1 = new JTextField("",10);
	JTextField jtf2 = new JTextField("",10);
	JTextField jtf5 = new JTextField("",10);
	
	// 버튼
	JButton jb1 = new JButton("찾기");
	JButton jb2= new JButton("확인");
	
	// 임시 비밀번호
	String unpw;
	public SearchPW() {
		setLayout(new GridLayout(2,5));
		
		// 아이디 입력 전화번호 입력 찾기(버튼)
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jb1);
		
		// 임시비밀번호 빈칸 인증번호 입력 확인(버튼)
		add(jl3);
		add(spw);
		add(jl5);
		add(jtf5);
		add(jb2);
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent ae) {//비번초기화
		String s = ae.getActionCommand();
		String Id = jtf1.getText();
		String PhoneNumber = jtf2.getText();
		informPersonnal informP = new informPersonnal("",Id);
		
		if(s.equals("찾기")) {
			if(Id.equals("") || PhoneNumber.equals("")) {
				JOptionPane.showMessageDialog(null,"사용자 정보 입력!","",JOptionPane.PLAIN_MESSAGE);
			}
			else {
				id = informP.id;
				ph = informP.phoneNumber;
				if(PhoneNumber.equals(ph)) {
					// 인증번호 생성 및 전역변수에 넣기
					Random r = new Random();
					for(int i=0; i<4;i++) {
						num[i] = r.nextInt(9)+1;
					}
					
					// 인증번호 출력
					String cert="";
					for(int i=0; i<4;i++) {
						cert+=Integer.toString(num[i]);
					}
					JOptionPane.showMessageDialog(null,"인증번호 : "+cert,"",JOptionPane.PLAIN_MESSAGE);

				}
				else {
					JOptionPane.showMessageDialog(null,"아이디/비밀번호가 없습니다","",JOptionPane.PLAIN_MESSAGE);
				}
			}
		}
		else {
			userDAO userDAO = new userDAO();
			User user = new User();
			String c = jtf5.getText();
			if(c.length() != 4){
				JOptionPane.showMessageDialog(null,"인증번호4자리를 입력하세요","",JOptionPane.PLAIN_MESSAGE);
			}
			else {
				String[] x = c.split("");
				int[] wnum = new int[4];
				for(int i=0;i<4;i++) wnum[i] = Integer.parseInt(x[i]);
				int ca =0;
				for(int i=0;i<4;i++) {
					if(wnum[i] != num[i]) {
						ca=1;
						break;
					}
					else ca=0;
				}
				if(ca==1) {
					spw.setText("인증번호 다시!");
				}
				else {
					// 임시 비밀번호 생성, 아스키 코드로 영어 대문자만 사용할수 있게 함
					Random rpw = new Random();
					GeneratePW generatePW = new GeneratePW();
					unpw=generatePW.generatePassword();
					
					// 임시 비밀번호를 출력
					spw.setText(unpw);
					// 임시 비밀번호를 데이터베이스에 저장
					user.setPassword(unpw);
					user.setId(Id);
					userDAO.updatePWUserValues(user);
					
					// 초기화
					jtf1.setText("");
					jtf2.setText("");
					jtf5.setText("");
				}
			}
		}
	}
}

class Search extends JFrame{
	JLabel jl1, jl2;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	JButton jb1;
	JTextField jtf1, jtf2;
	public Search() {
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		
		JTabbedPane jtp = new JTabbedPane();
		SearchID Id = new SearchID();
		SearchPW Pw = new SearchPW();
		jtp.addTab("아이디 찾기", Id);
		jtp.addTab("비밀번호 초기화", Pw);
		getContentPane().add(jtp);
		
		setTitle("아이디/비밀번호 찾기");
		setSize(600,150);
		setVisible(true);
		setLocationRelativeTo(null);
	}
}