package sql;

public class passwordRegex {
    public boolean validatePassword(String password) {
        String regexPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        //정규식
        // 입력된 비밀번호가 정규식 패턴에 맞는지 여부를 반환합니다.
        return password.matches(regexPattern);//불리안
    }
}
