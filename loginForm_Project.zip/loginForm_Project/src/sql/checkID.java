package sql;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class checkID extends userDAO{
    JTextField idText;
    String id, name;
    List<String> idList, nameList;
    // 아이디 확인
    checkID(JTextField jtf){
        this.idText=jtf;
        id = idText.getText();
        idList = getColumnValues("id");
        nameList = getColumnValues("name");
    }
    
    // 아이디를 최신화 시킨다
    boolean check(){
        for (int i = 0; i < idList.size(); i++) {
            if (idList.get(i).equals(id)){
            	name = nameList.get(i);
            	return true;
            }
        }
        return false;
    }
    
    // 이름을 반환
    String namecheck() {
    	return this.name;
    }
}
