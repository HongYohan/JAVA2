package sql;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class informPersonnal extends userDAO{
    String id, name, phoneNumber, address, email;
    List<String> idList, nameList, phoneNumberList, addressList, emailList; // 각 행의 값을 저장
    public informPersonnal(String nameText,String idText){
        this.name = nameText;
        this.id = idText;
        idList = getColumnValues("id");
        nameList = getColumnValues("name");
        phoneNumberList = getColumnValues("phoneNumber");
        addressList = getColumnValues("address");
        emailList = getColumnValues("email");
        
        // 이름쪽이 공백이라면 id를 찾는것, 비밀번호 찾기에 사용됨
        if(name.equals("")) {
        	for (int i = 0; i < idList.size(); i++) {
                if (idList.get(i).equals(id)){
                	id = idList.get(i);
                	phoneNumber = phoneNumberList.get(i);
                }
            }
        }
        
        // id쪽이 공백이라면 name을 찾는 것
        else if(id.equals("")){
        	for (int i = 0; i < nameList.size(); i++) {
                if (nameList.get(i).equals(name)){
                	id = idList.get(i);
                	phoneNumber = phoneNumberList.get(i);
                	address = addressList.get(i);
                	email = emailList.get(i);
                }
            }
        }
    }
}
