package sql;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class Admin extends JFrame implements ActionListener{
	JLabel jl;
	JButton jb1, jb2; //사용자 정보, 로그아웃
	public Admin() {
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		
		jl = new JLabel("반가워요!  관리자님");
		jb1 = new JButton("사용자 정보");
		jb2 = new JButton("로그아웃");
		
		JPanel jp1 = new JPanel();
		jp1.add(jl);
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(2,0));
		jp2.add(jb1);
		jp2.add(jb2);

		ct.add(jp1);
		ct.add(jp2);
		
		// 각 버튼 수행
		jb1.addActionListener(this);
		jb2.addActionListener(this);

		setTitle("관리자 폼");
		setSize(250,100);
		setVisible(true);
		setLocationRelativeTo(null);
	}
	public void actionPerformed(ActionEvent ae) {
		String s = ae.getActionCommand();
		if(s.equals("로그아웃")) {
			dispose();
		}
		else {
			// 사용자 정보 폼 로드
			new Detailx();
		}
	}
}


class Detailx extends JFrame implements ActionListener, ItemListener {
    JLabel jl1, jl2, jl3, jl4;
    JTextField name, phone, address, email, admin;
    JButton jb1, jb2; // 나가기, 수정
    JComboBox jcb; // 이름 로드 박스
    userDAO userDAO = new userDAO();
    int cnt=0;
    public Detailx() {
        Container ct = getContentPane();
        ct.setLayout(null);
        
        // 콤보박스 초기화
		jcb = new JComboBox();
		jcb.setSize(200, 20);
		jcb.setLocation(30, 5);
		jcb.addItem("데이터 선택");
		
		// 관리자 모드, 관리자 데이터 생성 필수!
		admin = new JTextField("admin");
		checkID checkID = new checkID(admin);
		checkID.check(); // 여기에 있던 데이터 불러오기
		List<String> values = userDAO.getColumnValues("name");
		for(int i=0;i<checkID.nameList.size();i++) jcb.addItem(values.get(i));
		ct.add(jcb);
		
        jl1 = new JLabel("이름: ");
        jl1.setSize(60, 20);
        jl1.setLocation(30, 30);
        jl2 = new JLabel("전화번호: ");
        jl2.setSize(60, 20);
        jl2.setLocation(30, 60);
        jl3 = new JLabel("주소: ");
        jl3.setSize(60, 20);
        jl3.setLocation(30, 90);
        jl4 = new JLabel("이메일: ");
        jl4.setSize(60, 20);
        jl4.setLocation(30, 120);

        ct.add(jl1);
        ct.add(jl2);
        ct.add(jl3);
        ct.add(jl4);

        name = new JTextField("", 10);
        name.setSize(140, 20);
        name.setLocation(100, 30);
        name.setEditable(false);
        phone = new JTextField("", 10);
        phone.setSize(140, 20);
        phone.setLocation(100, 60);
        address = new JTextField("", 10);
        address.setSize(140, 20);
        address.setLocation(100, 90);
        email = new JTextField("", 10);
        email.setSize(140, 20);
        email.setLocation(100, 120);


        ct.add(name);
        ct.add(phone);
        ct.add(address);
        ct.add(email);

        jb1 = new JButton("나가기");
        jb1.setSize(100, 30);
        jb1.setLocation(140, 150);
        jb2 = new JButton("수정");
        jb2.setSize(70, 30);
        jb2.setLocation(60, 150);

        ct.add(jb1);
        ct.add(jb2);
        
        jcb.addItemListener(this);
        jb1.addActionListener(this);
        jb2.addActionListener(this);

        setTitle("개인정보");
        setSize(280, 250);
        setVisible(true);
        setLocationRelativeTo(null);
    }
    
    public void itemStateChanged(ItemEvent ie) {
    	String na, ph, ars, mail;
    	// 콤보박스의 데이터 값을 가져오면 해당 폼에 로드됨
    	String Name = (String)ie.getItem();
    	informPersonnal informP = new informPersonnal(Name,"");
		na = informP.name;
		ph=informP.phoneNumber;
		ars=informP.address;
		mail=informP.email;
		
		name.setText(na);
		phone.setText(ph);
		address.setText(ars);
		email.setText(mail);
    }

    public void actionPerformed(ActionEvent ae) {
		User user = new User();
    	String s = ae.getActionCommand();
    	if(s.equals("수정")) {
    		// 로드된 데이터를 데이터베이스에 저장 시킨다, 이름을 기준으로 함
    		user.setPhoneNumber(phone.getText());
            user.setAddress(address.getText());
            user.setEmail(email.getText());
            user.setName(name.getText());
            userDAO.updateUserValues(user);
            JOptionPane.showMessageDialog(null,"수정 완료","",JOptionPane.PLAIN_MESSAGE);
    	} else {
    		dispose();
    	}
    }
}
