package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class userDAO extends encode_Decode{

    String jdbcUrl = "jdbc:mysql://localhost/membershipDB";
    Connection conn;
    String id = "root";
    String pw = "1234";
    PreparedStatement pstmt;
    ResultSet rs;

    String[] items = {};
    String sql;

    // DB연결 메소드
    public void connectDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcUrl,id,pw);
        } catch (ClassNotFoundException e) {
            System.out.println("jdbc 드라이버 로드 오류");
        } catch (SQLException e){
            System.out.println("SQL 실행 에러");
        }
    }

    // DB 연결 종료 메소드
    public void closeDB() {
        try {
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> getColumnValues(String colName){
        connectDB();//DB의 coloum 한줄 colname 기준으로 String List로 모두 가져옴
        List<String> values = new ArrayList<>();
        sql="SELECT " + colName + " FROM user";//에스큐엘 문. user테이블에서 colname으로 가져옴
        try {
            pstmt=conn.prepareStatement(sql);//연결된 디비에 특정 sql문 실행하기위해 지정
            rs=pstmt.executeQuery();//쿼리문 실행. result set에 값 가져오기
            while (rs.next()){// id값을 하나씩 가져와서
                values.add(rs.getString(colName));//리스트에 하나씩 더하기
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            closeDB();//DB 문닫기
        }
        return values;
    }

    // 회원가입 폼
    public void insertUserValues(User user){
        connectDB();
        sql="insert into user values ('"+user.getId()+"', '"+encode(user.getPassword())+"', '"+user.getName()
                +"', '"+user.getPhoneNumber()+"', '"+user.getAddress()+"', '"
                +user.getEmail()+"')";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.execute();
            
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            closeDB();
        }
    }
    
    // 저장된 데이터 값 수정, Admin폼에서
    public void updateUserValues(User user){
        connectDB();
        sql = "update user set phoneNumber=?, address=?, email=? where name=?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1, user.getPhoneNumber());
            pstmt.setString(2, user.getAddress());
            pstmt.setString(3, user.getEmail());
            pstmt.setString(4, user.getName());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            closeDB();
        }
    }
    
    // 저장된 개인 데이터 수정, id를 기준으로 개인 정보 수정, Logined폼에 사용됨
    public void updatePersonnalUserValues(User user){
        connectDB();
        sql = "update user set name=?, phoneNumber=?, address=?, email=? where id=?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getPhoneNumber());
            pstmt.setString(3, user.getAddress());
            pstmt.setString(4, user.getEmail());
            pstmt.setString(5, user.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            closeDB();
        }
    }
    
    // 저장된 개인 비밀번호 수정, id를 기준으로 설정, 비밀번호 찾기에 이용됨
    public void updatePWUserValues(User user){
        connectDB();
        sql = "update user set password=? where id=?";
        try {
            pstmt=conn.prepareStatement(sql);
            pstmt.setString(1, encode(user.getPassword()));
            pstmt.setString(2, user.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            closeDB();
        }
    }

    // 개인 데이터 삭제, id를 기준으로 삭제함
    public boolean deleteUserValues(String id){
        connectDB();
        sql = "delete from user where id=?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.executeUpdate();
        }
        catch(SQLException e) {
            e.printStackTrace();
            return false;
        }
        finally {
            closeDB();
        }
        return true;
    }
}