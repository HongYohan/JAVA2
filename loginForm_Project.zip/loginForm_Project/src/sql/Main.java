package sql;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class SearchClass implements MouseListener{
	JLabel jl3;
	public SearchClass(JLabel jl3){
        this.jl3 = jl3;
        jl3.setOpaque(true);
    }
	@Override
	public void mouseClicked(MouseEvent me)  {
		new Search(); // 아이디/비밀번호 찾기 폼
	}
	@Override
	public void mouseReleased(MouseEvent me) {
	}
	@Override
	public void mousePressed(MouseEvent me) {
	}
	@Override
	public void mouseExited(MouseEvent me) {
		jl3.setForeground(Color.black);
	}
	@Override
	public void mouseEntered(MouseEvent me) {
		jl3.setForeground(Color.red);
	}
}

class MakeClass implements MouseListener{
	JLabel jl4;
	public MakeClass(JLabel jl4){
        this.jl4 = jl4;
        jl4.setOpaque(true);
    }
	@Override
	public void mouseClicked(MouseEvent me)  {
		new Make(); // 회원가입 폼
	}
	@Override
	public void mouseReleased(MouseEvent me) {
	}
	@Override
	public void mousePressed(MouseEvent me) {
	}
	@Override
	public void mouseExited(MouseEvent me) {
		jl4.setForeground(Color.black);
	}
	@Override
	public void mouseEntered(MouseEvent me) {
		jl4.setForeground(Color.red);
	}
}


class Membership extends JFrame implements ActionListener{
	JLabel jl1, jl2, jl3, jl4;
	JTextField Mid; // Main ID
	JPasswordField Mpw; // Main PW
	boolean CID = false, CPW = false; // 아이디 비밀번호 체크
	public Membership() {
		Container ct = getContentPane();
		ct.setLayout(new BorderLayout());
		
		// 로그인 영역
		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(2,2));
		
		JButton jb = new JButton("로그인");
		jl1 = new JLabel("아이디");
		jl2 = new JLabel("비밀번호");
		Mid = new JTextField("",10);
		Mpw = new JPasswordField("",10);

		jp1.add(jl1);
		jp1.add(Mid);
		jp1.add(jl2);
		jp1.add(Mpw);
		
		// 찾기 및 회원가입 영역
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(1,2));
		
		jl3 = new JLabel("아이디/비밀번호 찾기");
		jl4 = new JLabel("회원가입");
		
		jp2.add(jl3);
		jp2.add(jl4);
		
		// 마우스 이벤트
		jl3.addMouseListener(new SearchClass(jl3));
		jl4.addMouseListener(new MakeClass(jl4));
		
		// 결합
		ct.add(jp1, BorderLayout.WEST);
		ct.add(jb, BorderLayout.EAST);
		ct.add(jp2, BorderLayout.SOUTH);
		
		// 로그인
		jb.addActionListener(this);
		
		setTitle("로그인");
		setSize(300,100);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) {
		String mpw = new String(Mpw.getPassword());
		if(Mid.getText().equals("")){
			JOptionPane.showMessageDialog(null,"아이디를 입력해주세요","",JOptionPane.PLAIN_MESSAGE);
		} else if(mpw.equals("")){
			JOptionPane.showMessageDialog(null,"비밀번호를 입력해주세요","",JOptionPane.PLAIN_MESSAGE);
		} else {
			CID = false;
			CPW = false;
			
			// 추가
			checkID checkID = new checkID(Mid);
			checkPW checkPW = new checkPW(Mpw);
			
			// 아이디 확인
			if (checkID.check()==true){
				CID=true;
			}
			else {
				JOptionPane.showMessageDialog(null,"잘못된 아이디입니다","",JOptionPane.PLAIN_MESSAGE);
			}
			
			// 비밀번호 확인
			if (checkPW.check()==true){
				CPW=true;
			}
			else {
				JOptionPane.showMessageDialog(null,"잘못된 비밀번호입니다","",JOptionPane.PLAIN_MESSAGE);
			}
			
			// 로그인
			if(CID && CPW) {
				if(Mid.getText().equals("admin") && mpw.equals("admin123")) { //관리자 모드로 접근
					new Admin();
					Mid.setText("");
					Mpw.setText("");
				 }
				else {
					new Logined(checkID.namecheck()); // 해당 아이디에서 있는 이름을 기준으로 로드함
					Mid.setText("");
					Mpw.setText("");
				}
			}
		}
	}
}


public class Main {
	public static void main(String[] args) {
		new Membership();
	}
}