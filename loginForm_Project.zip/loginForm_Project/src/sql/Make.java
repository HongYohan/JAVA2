package sql;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

class Make extends JFrame implements ActionListener {
	boolean CID = false;
    userDAO userDAO = new userDAO();
	JLabel jl1, jl2, jl3, jl4, jl5, jl6, jl7, re1, re2, re3, re4;
	JButton jb1, jb2;
	JTextField jtf1;
    JTextField jtf2;
    JTextField jtf3;
    JTextField jtf4;
    JTextField jtf5;
	JPasswordField jpf1, jpf2;
	
	int[] num = new int[4];
	public Make() {
		Container ct = getContentPane();
		ct.setLayout(null);

        jl1 = new JLabel("아이디:");
        jl1.setSize(80,20);
        jl1.setLocation(30,30);
        jl1.setHorizontalAlignment(JLabel.RIGHT);

		jl2 = new JLabel("비밀번호:");
		jl2.setSize(80,20);
        jl2.setLocation(30,70);
        jl2.setHorizontalAlignment(JLabel.RIGHT);

		jl3 = new JLabel("비밀번호확인:");
		jl3.setSize(80,20);
        jl3.setLocation(30,110);
        jl3.setHorizontalAlignment(JLabel.RIGHT);

		jl4 = new JLabel("이름:");
		jl4.setSize(80,20);
        jl4.setLocation(30,150);
        jl4.setHorizontalAlignment(JLabel.RIGHT);

		jl5 = new JLabel("전화번호:");
		jl5.setSize(80,20);
        jl5.setLocation(30,190);
        jl5.setHorizontalAlignment(JLabel.RIGHT);

		jl6 = new JLabel("주소:");
		jl6.setSize(80,20);
        jl6.setLocation(30,230);
        jl6.setHorizontalAlignment(JLabel.RIGHT);

		jl7 = new JLabel("이메일:");
		jl7.setSize(80,20);
        jl7.setLocation(30,270);
        jl7.setHorizontalAlignment(JLabel.RIGHT);

        ct.add(jl1);
        ct.add(jl2);
        ct.add(jl3);
        ct.add(jl4);
        ct.add(jl5);
        ct.add(jl6);
        ct.add(jl7);//JFrame에 JLabel를 추가

        jtf1 = new JTextField();//아이디
        jtf1.setSize(120,20);
        jtf1.setLocation(130,30);

		jpf1 = new JPasswordField();//비번
		jpf1.setSize(120,20);
		jpf1.setLocation(130,70);

		jpf2 = new JPasswordField();//비번2
		jpf2.setSize(120,20);
		jpf2.setLocation(130,110);

		jtf2 = new JTextField();//이름
		jtf2.setSize(120,20);
        jtf2.setLocation(130,150);

		jtf3 = new JTextField();//전번
		jtf3.setSize(120,20);
        jtf3.setLocation(130,190);

		jtf4 = new JTextField();//주소
		jtf4.setSize(120,20);
        jtf4.setLocation(130,230);

		jtf5 = new JTextField();//이메일
		jtf5.setSize(120,20);
        jtf5.setLocation(130,270);
        
        ct.add(jtf1);//아이디
        ct.add(jpf1);//비번
        ct.add(jpf2);//비번2
        ct.add(jtf2);//이름
        ct.add(jtf3);//전번
        ct.add(jtf4);//주소
        ct.add(jtf5);//이메일
        //JFrame에 JTextField를 추가
        
        re1 = new JLabel(""); // 아이디 중복 확인
        re1.setSize(150,20);
        re1.setLocation(270,10);
        
        ct.add(re1);
		
        jb1 = new JButton("ID 중복확인");
        jb1.setSize(100,20);
        jb1.setLocation(270,30);
        jb1.addActionListener(this);

        re2 = new JLabel(""); // 비번 확인
        re2.setSize(150,20);
        re2.setLocation(270,110);
        ct.add(re2);

        re3 = new JLabel(""); // 정규식 확인
        re3.setSize(150,20);
        re3.setLocation(270,70);
        ct.add(re3);

        re4 = new JLabel("8자리 이상 숫자,소문자,대문자,특수문자 필수"); // 비번 확인
        re4.setSize(300,20);
        re4.setLocation(120,87);
        ct.add(re4);

        jb2 = new JButton("회원가입");
        jb2.setSize(100,20);
        jb2.setLocation(270,310);
        
        ct.add(jb1);
        ct.add(jb2);
        
        jb2.addActionListener(this);
		
        setTitle("회원가입");
		setSize(450,400);
		setVisible(true);
		setLocationRelativeTo(null);
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae) {
        User user = new User();
		String s = ae.getActionCommand();
        while (true){
            if (s.equals("ID 중복확인")){
                CID=false;//항상 default가 false
                checkID checkID = new checkID(jtf1);
                if (checkID.check()==true){
                    re1.setText("중복입니다");
                    break;
                }else if(jtf1.getText().equals("")) {
                    re1.setText("아이디를 입력해주세요");
                    break;
                }else {
                    re1.setText("사용가능한 아이디입니다");
                    user.setId(jtf1.getText());//임시 유저의 아이디 저장
                    CID=true;
                }
            }


            if(s.equals("회원가입")) {
                boolean CID2=false;
                boolean CID3=false;
                boolean CID4=false;
                passwordRegex passwordRegex = new passwordRegex();
                String pw_str = String.valueOf(jpf1.getPassword());
                if (passwordRegex.validatePassword(pw_str)){
                    re3.setText("안전한 비밀번호");
                    CID2=true;
                }else{
                    re3.setText("불완전한 비밀번호");
                    break;
                }

                checkDoublePW checkDoublePW = new checkDoublePW(jpf1, jpf2);
                int flag =checkDoublePW.check();
                if (flag==1){//비번 이중체크
                    re2.setText("비밀번호는 동일합니다");
                    CID3=true;
                }else if (flag==-1){
                    re2.setText("비밀번호가 비었습니다");//공백일 경우.
                    break;
                }else{
                    re2.setText("비밀번호가 다릅니다");
                    break;
                }

                if (jtf2.getText().isEmpty()||jtf3.getText().isEmpty()||jtf4.getText().isEmpty()||jtf5.getText().isEmpty()){
                    CID4=false;//모든 칸중에 하나라도 비어있다면 false
                }else  CID4=true;

                if (CID&&CID2&&CID3&&CID4){
                    user.setId(jtf1.getText());
                    user.setPassword(String.valueOf(jpf1.getPassword()));
                    user.setName(jtf2.getText());
                    user.setPhoneNumber(jtf3.getText());
                    user.setAddress(jtf4.getText());
                    user.setEmail(jtf5.getText());
                    userDAO.insertUserValues(user);
                    JOptionPane.showMessageDialog(null,"회원가입 완료","",JOptionPane.PLAIN_MESSAGE);
                    dispose();
                    break;
                }else if (!CID){
                    JOptionPane.showMessageDialog(null,"ID중복확인을 해주세요","",JOptionPane.PLAIN_MESSAGE);
                }else JOptionPane.showMessageDialog(null,"모든 정보를 입력해주세요","",JOptionPane.PLAIN_MESSAGE);
            }
            break;
        }
	}
}