package sql;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

public class Logined extends JFrame implements ActionListener {
	JLabel jl;
	JButton jb1, jb2;
	String id, na, ph, ars, mail, Name;

	public Logined(String name) { // 로그인 버튼 눌렀을때의 이름을 가져옴
		this.Name = name;
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());

		jl = new JLabel("반가워요!  " + Name + "님");
		jb1 = new JButton("내 정보");
		jb2 = new JButton("로그아웃");

		JPanel jp1 = new JPanel();
		jp1.add(jl);
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(2, 0));
		jp2.add(jb1);
		jp2.add(jb2);

		ct.add(jp1);
		ct.add(jp2);

		jb1.addActionListener(this);
		jb2.addActionListener(this);

		setTitle("로그인 후 폼");
		setSize(250, 100);
		setVisible(true);
		setLocationRelativeTo(null);
	}


	public void actionPerformed(ActionEvent ae) {
		// 개인정보 저장
		informPersonnal informP = new informPersonnal(Name, "");
		id = informP.id;
		na = informP.name;
		ph = informP.phoneNumber;
		ars = informP.address;
		mail = informP.email;

		String s = ae.getActionCommand();
		if (s.equals("로그아웃")) {
			dispose();
		} else {
			// 개인정보 폼에 바로 개인정보를 로드함
			new Detail(id, na, ph, ars, mail, this);
		}
	}

	class Detail extends JFrame implements ActionListener {
		JLabel jl1, jl2, jl3, jl4, jl5, jl6, jl7;
		JTextField name, phone, address, email;
		JButton jb1, jb2;
		String Name, ID;
		userDAO userDAO = new userDAO();
		JPasswordField jpf1, jpf2, jpf3;
		JFrame parent;

		// 폼 로드와 동시에 개인정보들을 바로 가져옴
		public Detail(String Id, String Na, String Ph, String Ars, String Mail, JFrame parent) {
			this.Name = Na;
			this.ID = Id; // id를 전역변수로 둠
			this.parent=parent;
			Container ct = getContentPane();
			ct.setLayout(null);

			jl1 = new JLabel("이름: ");
			jl1.setSize(60, 20);
			jl1.setLocation(30, 30);

			jl2 = new JLabel("전화번호: ");
			jl2.setSize(60, 20);
			jl2.setLocation(30, 60);

			jl3 = new JLabel("주소: ");
			jl3.setSize(60, 20);
			jl3.setLocation(30, 90);

			jl4 = new JLabel("이메일: ");
			jl4.setSize(60, 20);
			jl4.setLocation(30, 120);

			jl5 = new JLabel("현재PW:");
			jl5.setSize(60, 20);
			jl5.setLocation(30, 150);

			jl6 = new JLabel("새PW:");
			jl6.setSize(60, 20);
			jl6.setLocation(30, 180);

			jl7 = new JLabel("PW재입력:");
			jl7.setSize(60, 20);
			jl7.setLocation(30, 210);

			jpf1=new JPasswordField(10);
			jpf1.setSize(140,20);
			jpf1.setLocation(100,150);

			jpf2=new JPasswordField(10);
			jpf2.setSize(140,20);
			jpf2.setLocation(100,180);

			jpf3=new JPasswordField(10);
			jpf3.setSize(140,20);
			jpf3.setLocation(100,210);

			name = new JTextField(Na, 10);
			name.setSize(140, 20);
			name.setLocation(100, 30);
			phone = new JTextField(Ph, 10);
			phone.setSize(140, 20);
			phone.setLocation(100, 60);
			address = new JTextField(Ars, 10);
			address.setSize(140, 20);
			address.setLocation(100, 90);
			email = new JTextField(Mail, 10);
			email.setSize(140, 20);
			email.setLocation(100, 120);


			jb1 = new JButton("수정");
			jb1.setSize(70, 30);
			jb1.setLocation(170, 240);
			jb2 = new JButton("회원탈퇴");
			jb2.setSize(100, 30);
			jb2.setLocation(30, 240);


			ct.add(jl1);
			ct.add(name);
			ct.add(jl2);
			ct.add(phone);
			ct.add(jl3);
			ct.add(address);
			ct.add(jl4);
			ct.add(email);
			ct.add(jb1);
			ct.add(jb2);
			ct.add(jl5);
			ct.add(jl6);
			ct.add(jl7);
			ct.add(jpf1);
			ct.add(jpf2);
			ct.add(jpf3);

			jb1.addActionListener(this);
			jb2.addActionListener(this);

			setTitle("개인정보");
			setSize(280, 330);
			setVisible(true);
			setLocationRelativeTo(null);

		}

		public void actionPerformed(ActionEvent ae) {
			User user = new User();
			checkPW checkPW = new checkPW(jpf1);
			checkDoublePW checkDoublePW = new checkDoublePW(jpf2, jpf3);
			String s = ae.getActionCommand();
			passwordRegex passwordRegex = new passwordRegex();
			int flag=checkDoublePW.check();//더블체크 플래그
			boolean flag2=passwordRegex.validatePassword(String.valueOf(jpf2.getPassword()));//정규식 플래그
			if (s.equals("수정")) {
				// 변경된 데이터를 가져옴
				// 데이터 저장 클래스 선언후 수행
				if(checkPW.check()){
					user.setName(name.getText());
					user.setPhoneNumber(phone.getText());
					user.setAddress(address.getText());
					user.setEmail(email.getText());
					user.setId(ID); // 전역변수로 둔 id를 기준으로 함

					if (flag==1&&flag2){
						user.setPassword(String.valueOf(jpf2.getPassword()));
						userDAO.updatePWUserValues(user);
						userDAO.updatePersonnalUserValues(user);
						JOptionPane.showMessageDialog(null,"수정 완료","",JOptionPane.PLAIN_MESSAGE);
						dispose();
						// 저장 후 종료
					}else if ((String.valueOf(jpf2.getPassword()).isEmpty())&&(String.valueOf(jpf3.getPassword()).isEmpty())){
						userDAO.updatePersonnalUserValues(user);
						JOptionPane.showMessageDialog(null,"수정 완료","",JOptionPane.PLAIN_MESSAGE);
						dispose();// 저장 후 종료
					}else if (!flag2){
						JOptionPane.showMessageDialog(null,"새PW가 필수조건을 만족하지 않습니다","",JOptionPane.PLAIN_MESSAGE);
					}else if(flag==0){
						JOptionPane.showMessageDialog(null,"새PW가 서로 일치하지 않습니다","",JOptionPane.PLAIN_MESSAGE);
					}else if (flag==-1){
						JOptionPane.showMessageDialog(null,"재입력 PW필드가 비어있습니다.","",JOptionPane.PLAIN_MESSAGE);
					}
				}else if (String.valueOf(jpf1.getPassword()).isEmpty()){
					JOptionPane.showMessageDialog(null,"데이터를 수정하려면 현재 PW를 입력하셔야합니다.","",JOptionPane.PLAIN_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,"현재PW가 틀렸습니다","",JOptionPane.PLAIN_MESSAGE);
				}
			} else if (s.equals("회원탈퇴")&&checkPW.check()) { // 회원탈퇴
				// 데이터를 db에서 삭제함
				userDAO.deleteUserValues(ID); // 전역변수로 둔 id를 기준으로 함
				JOptionPane.showMessageDialog(null, "회원탈퇴가 완료되었습니다.", "", JOptionPane.PLAIN_MESSAGE);
				dispose();
				addWindowListener(new WindowAdapter() {
					@Override
					public void windowClosed(WindowEvent e) {
						parent.dispose();//개인정보 창이 닫히면 로그인 후 폼도 닫힘
					}
				});
			} else {
				JOptionPane.showMessageDialog(null, "현재PW를 입력해주세요", "", JOptionPane.PLAIN_MESSAGE);
			}
		}

	}
}