package sql;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class checkPW extends userDAO implements ActionListener {
	JPasswordField pwText;
    String pw;
    List<String> pwList;
    encode_Decode encode_decode = new encode_Decode();
    checkPW(JPasswordField jpf){
        this.pwText=jpf;
        pw = new String(jpf.getPassword());
        pwList = getColumnValues("password");
    }
    boolean check(){
        String s;
        for (int i = 0; i < pwList.size(); i++) {
            s=encode_decode.decode(pwList.get(i));
            if (s.equals(pw)){
                return true;
            }
        }
        return false;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
